<?php

namespace Database\Seeders;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Job;
use App\Models\Skill;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // \App\Models\User::factory(10)->create();
        $jobs = [
            [
                "name" => "Frontend Web Programmer"
            ],
            [
                "name" => "Fullstack Web Programmer"
            ],
            [
                "name" => "Quality Control"
            ],
        ];
        $skills = [
            [
                "name" => "PHP"
            ],
            [
                "name" => "PostgreSQL"
            ],
            [
                "name" => "API (JSON, REST)"
            ],
            [
                "name" => "Version Control System (Gitlab, Github)"
            ],
        ];

        foreach($jobs as $job){
            Job::create([
                'name' => $job['name'],
            ]);
        }
        foreach($skills as $skill){
            Skill::create([
                'name' => $skill['name'],
            ]);
        }
    }
}
