<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class Skill_set extends Model
{
    use HasFactory;
    
    protected $fillable = [
        'candidate_id','skill_id'
    ];

    public $timestamps = false;

    public function candidate()
    {
        return $this->belongsTo(Candidate::class);
    }

    public function skills()
    {
        return $this->belongsToMany(Skill::class);
    }

}
