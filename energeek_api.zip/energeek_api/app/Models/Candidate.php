<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Wildside\Userstamps\Userstamps;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Candidate extends Model
{
    use HasFactory, Userstamps, SoftDeletes;

    protected $fillable = [
        'job_id','name','email','phone','year'
    ];

    public function job()
    {
        return $this->BelongTo(Job::class);
    }
    public function skillSets()
    {
        return $this->hasMany(SkillSet::class);
    }

}
