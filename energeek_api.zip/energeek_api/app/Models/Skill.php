<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Wildside\Userstamps\Userstamps;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class Skill extends Model
{
    use HasFactory, Userstamps, SoftDeletes;

    protected $fillable = [
        'name'
    ];

    public function skillSets()
    {
        return $this->belongsToMany(Skill_Set::class);
    }
}
