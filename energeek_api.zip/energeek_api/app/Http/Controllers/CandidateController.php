<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Candidate;

class CandidateController extends Controller
{
    public function show(){
        $data = Candidate::all();
        return response()->json([
            "data" => $data
        ]);
    }
}
