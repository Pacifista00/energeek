<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\Candidate;
use App\Models\Skill_set;

class ApplicationController extends Controller
{
    public function store(Request $request){
        $validator = Validator::make($request->all(), [
            'job' => 'required',
            'name' => 'required',
            'email' => 'required|email|unique:candidates,email',
            'phone' => 'required|numeric|unique:candidates,phone',
            'year' => 'required',
            'skills' => 'required|array',
            'skills.*' => 'distinct',
        ], [
            'job.required' => 'Pekerjaan harus diisi',
            'name.required' => 'Nama harus diisi',
            'email.required' => 'Email harus diisi',
            'email.email' => 'Email tidak sesuai, sertakan @ pada alamat email',
            'email.unique' => 'Email yang anda masukkan sudah pernah digunakan.',
            'phone.required' => 'No. Telp harus diisi',
            'phone.numeric' => 'No. Telp harus berupa angka',
            'phone.unique' => 'No. Telp sudah pernah digunakan',
            'year.required' => 'Tahun lahir harus diisi',
            'skills.required' => 'Kemampuan harus diisi',
        ]);
        
        if ($validator->fails()) {
            // Validasi gagal
            return response()->json([
                'status' => 'error',
                'message' => 'Validasi gagal',
                'errors' => $validator->errors()->all(),
            ], 422);
        }    

        $dataCandidate = [
            'job_id' => $request->job,
            'name' => $request->name,
            'email' => $request->email,
            'phone' => $request->phone,
            'year' => $request->year,
        ];

        $id = Candidate::insertGetId($dataCandidate);

        for ($i=0; $i < count($request->skills); $i++) {
            Skill_set::insert([
                "candidate_id" => $id,
                "skill_id" => $request->skills[$i]
            ]);
        }

        return response()->json([
            "message" => "Data berhasil ditambahkan."
        ]);
    }
}
