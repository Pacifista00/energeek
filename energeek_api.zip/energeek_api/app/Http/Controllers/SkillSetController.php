<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Skill_set;

class SkillSetController extends Controller
{
    public function show(){
        $data = Skill_set::all();
        return response()->json([
            "data" => $data
        ]);
    }
}
