<template>
  <div class="login-box">
    <div class="login-logo">
      <img src="../assets/img/energeek2 1.png" />
    </div>
    <!-- /.login-logo -->
    <div class="card">
      <div class="card-body login-card-body">
        <p class="apply-header">Apply Lamaran</p>
        <form action="../../index3.html" method="post">
          <div class="mb-3">
            <p for="name" class="form-label text-lg">Nama Lengkap</p>
            <input
              type="text"
              class="form-control"
              id="name"
              placeholder="Cth: Jonathan Akbar"
              v-model="name"
            />
          </div>
          <div class="mb-3">
            <p for="job" class="form-label text-lg">Jabatan</p>
            <select
              id="jobSelect"
              class="form-select select2"
              aria-label="Default select example"
              v-model="job"
            >
              <option value="1">Frontend Web Programmer</option>
              <option value="2">Fullstack Web Programmer</option>
              <option value="3">Quality Control</option>
            </select>
          </div>
          <div class="mb-3">
            <p for="phone" class="form-label text-lg">Telepon</p>
            <input
              type="text"
              class="form-control"
              :class="{ 'border-danger': !isNumber }"
              id="phone"
              placeholder="Cth: 0893239851289"
              v-model="phone"
            />
            <p v-if="!isNumber" class="text-danger">
              No Telepon harus berupa angka
            </p>
          </div>
          <div class="mb-3">
            <p for="email" class="form-label text-lg">Email</p>
            <input
              type="email"
              class="form-control"
              :class="{ 'border-danger': !isValidEmail }"
              id="email"
              placeholder="Cth: energeekmail@gmail.com"
              v-model="email"
            />
            <p v-if="!isValidEmail" class="text-danger">
              Email tidak sesuai, sertakan @ pada alamat email
            </p>
          </div>
          <div class="mb-3">
            <p for="year" class="form-label text-lg">Tahun lahir</p>
            <VueDatePicker
              v-model="year"
              year-picker
              placeholder="Pilih Tahun"
            />
          </div>
          <div class="mb-3">
            <p for="skills" class="form-label text-lg">Skill Set</p>
            <select
              id="skillsSelect"
              class="form-select select2-multiple"
              name="states[]"
              multiple="multiple"
              data-placeholder="Pilih Skill"
              v-model="skills"
            >
              <option value="1">PHP</option>
              <option value="2">PostgreSQL</option>
              <option value="3">API (JSON, REST)</option>
              <option value="4">Version Control System (Gitlab, Github)</option>
            </select>
          </div>
        </form>

        <button @click="insertData" class="btn btn-danger">Apply</button>
      </div>
      <!-- /.login-card-body -->
    </div>
  </div>
</template>

<style src="../assets/css/style.css"></style>

<script setup>
import VueDatePicker from "@vuepic/vue-datepicker";
import "@vuepic/vue-datepicker/dist/main.css";
import { ref, onMounted } from "vue";
import axios from "axios";
import Swal from "sweetalert2";

const year = ref(new Date().getFullYear());
const name = ref("");
const job = ref("");
const email = ref("");
const isValidEmail = ref(true);
const phone = ref("");
const isNumber = ref(true);
const skills = ref([]);

const insertData = async () => {
  try {
    validateEmail(email.value);
    validateNumber(phone.value);
    const data = {
      job: $("#jobSelect").val(),
      name: name.value,
      email: email.value,
      phone: phone.value,
      year: year.value,
      skills: $("#skillsSelect").val(),
    };
    const response = await axios.post("http://127.0.0.1:8000/api/apply", data);
    console.log("Response:", response.data);
    if (response.status === 200) {
      Swal.fire({
        title: "Success!",
        text: "Lamaran Berhasil Dikirim!",
        icon: "success",
        confirmButtonText: "Selesai",
      });
    }
  } catch (error) {
    console.error("Error :", error);
    Swal.fire({
      title: "Terjadi Kesalahan!",
      text: "Email yang anda masukkan sudah pernah melamar dijabatan tersebut, silahkan memilih jabatan yang lain.",
      icon: "error",
      confirmButtonText: "Baiklah",
    });
  }
};
const validateEmail = (email) => {
  if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(email)) {
    isValidEmail.value = true;
  } else {
    isValidEmail.value = false;
  }
};
const validateNumber = (input) => {
  isNumber.value = !isNaN(input);
};

onMounted(() => {
  // Inisialisasi Select2 setelah komponen dirender
  $("#mySelect").select2();
  $(".select2").select2();
  $(".select2-multiple").select2();
  $("#jobSelect").on("change", function () {
    job.value = $(this).val();
  });
  $("#skillsSelect").on("change", function () {
    skills.value = $(this).val();
  });
});
</script>
