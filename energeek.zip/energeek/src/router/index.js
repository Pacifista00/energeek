import { createRouter, createWebHistory } from "vue-router";

import Apply from "../views/Apply.vue";

const routes = [
  {
    path: "/",
    component: Apply,
  },
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

export default router;
